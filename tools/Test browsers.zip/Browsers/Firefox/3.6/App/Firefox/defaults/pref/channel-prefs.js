//@line 2 "e:\builds\moz2_slave\rel-m-192-w32-bld\build\browser\app\profile\channel-prefs.js"
pref("app.update.channel", "release");
