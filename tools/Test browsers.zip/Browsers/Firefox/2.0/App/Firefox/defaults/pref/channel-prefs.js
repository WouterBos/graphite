//@line 2 "/cygdrive/c/builds/tinderbox/Fx-Mozilla1.8-Release/WINNT_5.2_Depend/mozilla/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "release");
