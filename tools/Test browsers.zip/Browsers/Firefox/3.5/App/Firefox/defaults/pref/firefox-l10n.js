//@line 36 "e:\builds\moz2_slave\rel-191-w32-bld\build\browser\locales\en-US\firefox-l10n.js"

//@line 38 "e:\builds\moz2_slave\rel-191-w32-bld\build\browser\locales\en-US\firefox-l10n.js"

pref("general.useragent.locale", "en-US");
